from .index_mul_2d import index_mul_2d
